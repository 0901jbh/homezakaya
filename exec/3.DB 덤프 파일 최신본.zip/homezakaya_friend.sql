CREATE DATABASE  IF NOT EXISTS `homezakaya` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `homezakaya`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8a606.p.ssafy.io    Database: homezakaya
-- ------------------------------------------------------
-- Server version	5.7.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `friend`
--

DROP TABLE IF EXISTS `friend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `friend` (
  `userAId` varchar(45) NOT NULL,
  `userBId` varchar(45) NOT NULL,
  `isConnected` tinyint(1) NOT NULL,
  PRIMARY KEY (`userAId`,`userBId`),
  KEY `userBId` (`userBId`),
  CONSTRAINT `friend_ibfk_1` FOREIGN KEY (`userAId`) REFERENCES `user` (`userId`) ON DELETE CASCADE,
  CONSTRAINT `friend_ibfk_2` FOREIGN KEY (`userBId`) REFERENCES `user` (`userId`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `friend`
--

LOCK TABLES `friend` WRITE;
/*!40000 ALTER TABLE `friend` DISABLE KEYS */;
INSERT INTO `friend` VALUES ('0901jbh','1',1),('1','0901jbh',1),('1','aaa',1),('1','ky014789',1),('10','3',1),('3','aaa',1),('3','ldw0318',1),('aaa','1',1),('aaa','3',1),('aaa','ldw0318',1),('aaaa','onyongx',1),('aaaa','ymj3539',1),('aaaa','yoonsik',1),('dummyyoung','onyongx',1),('dummyyoung','안녕',1),('ky014789','1',1),('ky014789','ldw0318',1),('ky014789','power916',1),('ky014789','ssafy',1),('ldw0318','3',1),('ldw0318','aaa',1),('ldw0318','ky014789',1),('mandu','ymj3539',1),('onyongx','aaaa',1),('onyongx','booksays',0),('onyongx','dummyyoung',1),('onyongx','yoonsik',1),('onyongx','안녕',1),('power916','ky014789',1),('power916','qwerty',1),('power916','ssafy',1),('qwerty','power916',1),('ssafy','booksays',0),('ssafy','ky014789',1),('ssafy','power916',1),('ssafy','ymj3539',1),('ymj3539','aaaa',1),('ymj3539','mandu',1),('ymj3539','ssafy',1),('yoonsik','aaaa',1),('yoonsik','onyongx',1),('안녕','dummyyoung',1),('안녕','onyongx',1);
/*!40000 ALTER TABLE `friend` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-14 16:31:00
