CREATE DATABASE  IF NOT EXISTS `homezakaya` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `homezakaya`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8a606.p.ssafy.io    Database: homezakaya
-- ------------------------------------------------------
-- Server version	5.7.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `topic`
--

DROP TABLE IF EXISTS `topic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topic` (
  `topicId` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(200) NOT NULL,
  PRIMARY KEY (`topicId`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topic`
--

LOCK TABLES `topic` WRITE;
/*!40000 ALTER TABLE `topic` DISABLE KEYS */;
INSERT INTO `topic` VALUES (1,'형제나 자매가 있나요? 첫째, 둘째, 막내 중 무엇인가요?'),(3,'어렸을 때 키우던 반려동물이 있나요? 반려동물을 키우고 싶어 했나요?'),(4,'어렸을 때 하던 운동이 있나요? 지금 하는 운동은 없나요?'),(5,'할 줄 아는 외국어가 있나요?'),(6,'세계에서 가장 좋아하는 곳은 어딘가요?'),(7,'어릴 때 가장 좋아했던 만화는 무엇인가요?'),(9,'학창 시절 가장 좋아했던 과목은 무엇인가요?'),(10,'유명인과 닮았다는 소리를 들어본 적 있나요?'),(11,'지금까지 만난 사람 중 가장 유명한 사람은 누구인가요?'),(12,'현재 데스크톱과 휴대폰 배경 화면은 무엇인가요?'),(13,'창피했던 경험에 대해 이야기해주세요.'),(14,'좋아하는 책은 무엇인가요?'),(15,'즐겨 보는 TV 프로그램이 있나요?'),(16,'좋아하는 영화는 무엇인가요?'),(17,'좋아하는 노래는 무엇인가요?'),(18,'받았던 선물 중 가장 좋았던 것은 무엇인가요?'),(19,'좋아하는 음악 장르는 무엇인가요?'),(20,'강아지와 고양이 중 무엇이 더 좋은가요? 아니면 둘 다 좋아하나요?'),(21,'좋아하는 영화 명대사는 무엇인가요?'),(22,'산과 바다 중 선택한다면?');
/*!40000 ALTER TABLE `topic` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-14 16:30:59
