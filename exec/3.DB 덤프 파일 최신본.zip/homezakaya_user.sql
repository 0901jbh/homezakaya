CREATE DATABASE  IF NOT EXISTS `homezakaya` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `homezakaya`;
-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8a606.p.ssafy.io    Database: homezakaya
-- ------------------------------------------------------
-- Server version	5.7.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `userId` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `nickname` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `mannerPoint` double NOT NULL DEFAULT '0',
  `evaluatedCount` int(11) NOT NULL DEFAULT '0',
  `alcoholPoint` double NOT NULL,
  `refreshToken` varchar(255) DEFAULT NULL,
  `state` varchar(10) NOT NULL DEFAULT 'offline',
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('0901jbh','1234','전병현','ssafy@ssafy.com',3,5,4,NULL,'offline'),('1','1','1','ssafy@ssafy.com',5.55555,1,4,NULL,'offline'),('10','10','십','ssafy@ssafy.com',1,1,1,NULL,'offline'),('2','058eca9b18','22','0901jbh@naver.com',0,0,0.5,NULL,'offline'),('3','3','3','950901jbh@gmail.com',0,0,0.5,'eyJhbGciOiJIUzI1NiIsInR5cGUiOiJKV1QifQ.eyJleHAiOjE2NzYzNDIxOTl9.TeBmGGAIR9P8aUwXaxHJ3pViA1k_V-6JP4eGvjDhKQc','online'),('4','4','4','4@4',2,5,0,'eyJhbGciOiJIUzI1NiIsInR5cGUiOiJKV1QifQ.eyJleHAiOjE2NzYzNjA5Mzd9.y9miIsK6hPQjYyK1jjwdJrUxMT17HsA7ITmjm3jux4M','online'),('aaa','aaa','aaa','aaa@aaa',1.5,1,30,NULL,'offline'),('aaaa','1234','더현수','gustn913@naver.com',5,1,20,NULL,'offline'),('booksays','123','booksayt','',0,0,3,NULL,'offline'),('dubi','ddd','ddd','suz.dev33@gmail.com',5,1,1,'eyJhbGciOiJIUzI1NiIsInR5cGUiOiJKV1QifQ.eyJleHAiOjE2NzYzNjMzOTJ9.Fq9kN4czKpKtw3bYj1fF9URzo1SjzI2PAoqcZdMF_Uo','online'),('dummyyoung','asdf123!!','정더미','moxnox63@naver.com',0,0,1,'eyJhbGciOiJIUzI1NiIsInR5cGUiOiJKV1QifQ.eyJleHAiOjE2NzYyOTU5Mjh9.Y3o6inbr7mt_W7rqbihJ3lFw0Ed1n7M0vn7irmQJe9Q','online'),('ky014789','1234','고진석','mer0120@naver.com',4,2,0.5,'eyJhbGciOiJIUzI1NiIsInR5cGUiOiJKV1QifQ.eyJleHAiOjE2NzYzNjIzMjd9.3ckIGc-aLn5W5Z28G2jA0IHCWI79Mv2gnLd6ST7nnA0','online'),('ldw0318','1234','동우','korealdw@naver.com',4.4,5,3000,NULL,'offline'),('mandu','1234','만두','ymj3539@gmail.com',1.5714285714285714,7,1,NULL,'offline'),('onyongx','1234','용','hello6815@naver.com',0,0,0.5,'eyJhbGciOiJIUzI1NiIsInR5cGUiOiJKV1QifQ.eyJleHAiOjE2NzYzNTA1NTJ9.R9Ejx-FeV9oK5x858-x-8wagD3jbExSmkQxlSRZbpz8','online'),('power916','1234','태형','',4.5,2,4,NULL,'offline'),('qwerty','1541','qwerty','qwerty@com',0,0,0,NULL,'offline'),('ssafy','ssafy','김싸피','ssafy@ssafy.com',5.08333325,4,4,NULL,'offline'),('sss','d98c7623da','ssafy','sss@aaa',3,9,4,NULL,'offline'),('www','www','www','www@www',0,0,1,NULL,'offline'),('ymj3539','1234','minju','ymj3539@naver.com',2.235294117647059,17,1,NULL,'offline'),('yoonsik','123123','윤시기','skyland310@naver.com',1.8333333333333333,3,310,NULL,'offline'),('안녕','1111','구경하러왔어','test202110071402@gmail.com',0,0,36.5,'eyJhbGciOiJIUzI1NiIsInR5cGUiOiJKV1QifQ.eyJleHAiOjE2NzYyODY4MDF9.uJssJv7OOFNXFJhNZTluoqrECHkk40gZ98ZGRrq-GDQ','online');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-14 16:30:58
